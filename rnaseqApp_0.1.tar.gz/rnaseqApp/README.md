# rnaseq_app

To be deployed with chin-ups (with the function deployApp() ), the packrat file must be removed, as there seem to be a problem with the package dependencies.

If their is an error of unrecognized character, delete files with ‘irregular’ characters.

The package RCytoscape cannot be built when deploying, because their it a problem with the package XMLRCP. All packages dependant of this package must be removed to deploy.